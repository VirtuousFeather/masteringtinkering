import re

file = open("inputdag3.txt").read()
rows = file.split("\n")

print("Number of trees", file.count("#"))
print("Number of snows", file.count("."))

height = len(rows)
length = len(rows[0])

print(len(rows))
print(len(rows[0]))


listPosJumps  = [[1, 1],[3,1],[5,1],[7,1],[1,2]]
multipliedTrees = 1

for miniList in listPosJumps:
    jumpRight = miniList[0]
    jumpDown = miniList[1]
    x = 0
    y = 0
    treeCounter = 0

    while y < height - 1:
        y = y + jumpDown
        x = x + jumpRight
        x = x % length
            
        currentPos = rows[y][x]
        
        if currentPos == '#':
            treeCounter = treeCounter + 1
    
    multipliedTrees = multipliedTrees*treeCounter


    
print(multipliedTrees)

    #print(y)
    

  
