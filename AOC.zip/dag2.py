import re

file = open("input.txt").read()
#print(file.split('\n'))

passwords = file.split('\n')

#for pw in passwords:
#    print(pw)
    
pw = passwords[0]
validPass = 0

for pw in passwords:
    match = re.findall("(\d+)-(\d+) (\w): (\w+)", pw)[0]
   # print(match)
    getal1 = int(match[0])
    getal2 = int(match[1])
    char = match[2]
    passString = match[3]
    
    geteld = passString.count(char)
    #print(geteld)
    
    if geteld >= getal1 and geteld <= getal2:
        validPass += 1
        
print(validPass)



# 1-3 a: abbbbbbb
# 1:3:a::bbabbbbb


validPass2 = 0

for pw in passwords:
    match = re.findall("(\d+)-(\d+) (\w): (\w+)", pw)[0]
   # print(match)
    getal1 = int(match[0])
    getal2 = int(match[1])
    char = match[2]
    passString = match[3]
    
    letter1 = passString[getal1-1]
    letter2 = passString[getal2-1]
    
    if letter1 == char and letter2 != char:
        
        validPass2 += 1
    
    if letter2 == char and letter1 != char:
        validPass2 += 1
    
    

print(validPass2)