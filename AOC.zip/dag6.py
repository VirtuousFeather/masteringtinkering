groups = open("inputdag6.txt").read().split("\n\n")

# for i in range(len(groups)):
# 	groups[i] = groups[i].replace("\n", "")

groups = [ group.replace("\n", "") for group in groups ]

print(groups[0])

# x = [1, 2, 3, 4, 5]
# print(x)
# y = [ getal * 2 for getal in x ]
# print(y)
# print(sum(y))

sumOfYesses = 0
for group in groups:
	lettersAlreadySeen = [] # List to keep track of letters already seen
	uniqueLettersSeen = 0   # Counter to count the unique letters
	# For each letter in the group
	for letter in group:
		# Is dit letter al eerder langs gekomen?
		# Letters die al zijn langsgekomen, zit in lettersAlreadySeen
		# Dus we willen kijken of de letters in de lijst lettersAlreadySeen zit
		isMyCurrentLetterAlreadySeen = False
		for i in range(len(lettersAlreadySeen)):
			if letter == lettersAlreadySeen[i]: # Als letter al gezien is
				isMyCurrentLetterAlreadySeen = True
		
		if not isMyCurrentLetterAlreadySeen:
			lettersAlreadySeen.append(letter)
			uniqueLettersSeen += 1
	
	sumOfYesses += uniqueLettersSeen
	print(uniqueLettersSeen, group)
print(sumOfYesses)



sumOfYesses = 0
for group in groups:
	lettersAlreadySeen = [] # List to keep track of letters already seen
	uniqueLettersSeen = 0   # Counter to count the unique letters
	# For each letter in the group
	for letter in group:
		if letter not in lettersAlreadySeen:
			lettersAlreadySeen.append(letter)
			uniqueLettersSeen += 1
	
	sumOfYesses += uniqueLettersSeen
print(sumOfYesses)



sumOfYesses = 0
for group in groups:
	sumOfYesses += len(sedt(group))
print(sumOfYesses)



print( sum([len(set(group)) for group in groups]) )


