import re

#idee:
#Importeer textfile en split deze in een aparte lijst van seats
#Nu heb je dus een lijst seats:     [0]=>fbbffbflr, etc.
#Verdeel seats lijst in 'rows' en 'columns' lijst
#voor rows lijst: eerste random 7 characters f/b in de strings van lijst seats
#voor columns lijst: de drie 3 characters l/r na len(rows) in de strings van lijst seats


file = open("inputdag5.txt").read()
seats = file.split("\n")

for rowsncolumns in range(len(seats)):
    seats[rowsncolumns] = seats[rowsncolumns].replace("\n", " ")
    patternRows = r'[f|b]{1}'
    #print (int(len(seats))) => gives 789 seats in total
    rows = re.findall(patternRows, seats[rowsncolumns])
    #print(seats[rowsncolumns])
    columns = re.findall(("\d"), seats[rowsncolumns])
    print (columns)
    
    #print(seats[rowsncolumns])
    

#print("\n".join(rows))
"""

for i in range(len(seats)):
    print("")
    pp = rows[i]
    pairs = pp.split(" ")
    print(pairs)

    ppattributes = {}
    numberOattr = 0
    
    
    for keynvalue in pairs: # keynvalue = "hgt:156cm"
        combokeynvalue = keynvalue.split(":") #combokeynvalue = ["hgt", "156cm"]
        ppattributes[ combokeynvalue[0] ] = combokeynvalue[1] # ppattributes["hgt"] = "156cm"
    
    #################################
    print(ppattributes)
    if 'byr' in ppattributes:
        v = int(ppattributes['byr'])
        if 1920 <= v <= 2002:
            numberOattr = numberOattr + 1
            
    if 'iyr' in ppattributes:
        v = int(ppattributes['iyr'])
        if 2010 <= v <= 2020:    
            numberOattr = numberOattr + 1
            
    if 'eyr' in ppattributes:
        v = int(ppattributes['eyr'])
        if 2020 <= v <= 2030:    
            numberOattr = numberOattr + 1
            
    if 'hgt' in ppattributes:
        if "cm" in ppattributes['hgt']:
            valuecm = int((ppattributes['hgt'][0:-2]))
            if 150 <= valuecm <= 193:
                numberOattr = numberOattr + 1
        
        if "in" in ppattributes['hgt']:
            valuein = int((ppattributes['hgt'][0:-2]))
            if 59 <= valuein <= 76:
                numberOattr = numberOattr + 1
        
    if 'hcl' in ppattributes:
        patroon = r'^#[a-z0-9]{6}$'
        if re.match(patroon, ppattributes['hcl']) is not None:
            numberOattr = numberOattr + 1
        
    if 'ecl' in ppattributes:
        eyeColors = ["amb","blu","brn","gry","grn","hzl","oth"]
        if ppattributes['ecl'] in eyeColors:
            numberOattr = numberOattr + 1
        
    if 'pid' in ppattributes:
        ninenumbers = r'^\d{9}$'
        if re.match(ninenumbers, ppattributes['pid']) is not None:
            numberOattr = numberOattr + 1
        
    
    if numberOattr == 7:
        validPP = validPP + 1
    print(validPP)    

    
    
    
emiel = {}

emiel['leeftijd'] = 27
emiel['studie'] = 'TCS'
emiel['huis'] = 'HuizeUnderground'
emiel['huisgenoten'] = ['Buntsma', 'Vos', 'de rest']

"""